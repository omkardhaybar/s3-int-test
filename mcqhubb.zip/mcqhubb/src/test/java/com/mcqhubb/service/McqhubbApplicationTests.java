package com.mcqhubb.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McqhubbApplicationTests {

	@Test
	void contextLoads() {
	}

}

//package com.mcqhubb.service;
//
//import org.testcontainers.spock.Testcontainers;
//import spock.lang.Shared;
//import spock.lang.Specification;
//
//@Testcontainers
//class PostgresContainerIT extends Specification {
//
//    @Shared
//    PostgreSQLContainer postgreSQLContainer = new PostgreSQLContainer(SpockTestImages.POSTGRES_TEST_IMAGE)
//            .withDatabaseName("foo")
//            .withUsername("foo")
//            .withPassword("secret")
//
//    def "waits until postgres accepts jdbc connections"()
//
//    {
//
//
//    }
//}

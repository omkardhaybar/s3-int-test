//package com.mcqhubb.service
//
//import org.testcontainers.containers.localstack.LocalStackContainer
//
//package com.mcqhubb.service;
//
//import org.testcontainers.spock.Testcontainers;
//import spock.lang.Shared;
//import spock.lang.Specification;
//
//@Testcontainers
//class PostgresContainerIT extends Specification {
//
//    @Shared
//    LocalStackContainer postgreSQLContainer = new LocalStackContainer(SpockTestImages.POSTGRES_TEST_IMAGE)
//            .withDatabaseName("foo")
//            .withUsername("foo")
//            .withPassword("secret")
//
//    def "waits until postgres accepts jdbc connections"()
//
//    {
//
//
//    }
//}
//

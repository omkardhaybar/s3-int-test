package com.mcqhubb.service.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class controller {
    @GetMapping("/")
    public ResponseEntity<Dto> fun(){
        Dto dto = new Dto();
        dto.setId(Long.valueOf(1));
        dto.setName("omkar");
        return ResponseEntity.ok(dto);
    }
}

package com.mcqhubb.service.controller;

import lombok.Data;

@Data
public class Dto {
    Long id;
    String name;
}
